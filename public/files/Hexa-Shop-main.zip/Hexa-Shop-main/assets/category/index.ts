export { default as TShirtsImage } from "./t-shirt.png";
export { default as PantImage } from "./pant.png";
export { default as ShoeImage } from "./shoe.png";
export { default as WatchImage } from "./watch.png";
export { default as ShirtImage } from "./shirt.png";