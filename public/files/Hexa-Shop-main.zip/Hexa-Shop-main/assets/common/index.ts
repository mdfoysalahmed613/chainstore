export { default as HeroImage } from "./hero.png";
export { DefaultAvatar } from "./default-avatar";
