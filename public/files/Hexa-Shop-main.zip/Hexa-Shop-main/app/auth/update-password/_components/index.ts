export { UpdatePasswordForm } from "./update-password-form";
