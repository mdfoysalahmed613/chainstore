import { CheckoutPageClient } from "./_components/checkout-page-client";

export const metadata = {
   title: "Checkout | Hexa Shop",
   description: "Complete your purchase",
};

export default function CheckoutPage() {
   return <CheckoutPageClient />;
}
