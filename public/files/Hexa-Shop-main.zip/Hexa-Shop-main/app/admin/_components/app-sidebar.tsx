"use client";

/**
 * Admin Sidebar
 *
 * Main navigation for admin panel. Features collapsible menu groups
 * that expand based on current route. Includes user profile footer.
 *
 * Structure:
 * - Dashboard (single link)
 * - Products (submenu: All, Categories, Inventory)
 * - Orders (single link)
 * - Customers (single link)
 * - Analytics (single link)
 * - Settings (submenu: Store, Shipping)
 */

import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Users,
  Settings,
  ChevronRight,
  BarChart3,
  Tag,
  Truck,
  Hexagon,
} from "lucide-react";
import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";

import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarFooter,
} from "@/components/ui/sidebar";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import FooterUser from "./footer-user";

const mainNavItems = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    href: "/admin",
  },
  {
    title: "Products",
    icon: Package,
    items: [
      { title: "All Products", href: "/admin/products" },
      { title: "Add New", href: "/admin/products/new" },
      { title: "Categories", href: "/admin/products/categories" },
      { title: "Inventory", href: "/admin/products/inventory" },
    ],
  },
  {
    title: "Orders",
    icon: ShoppingCart,
    items: [
      { title: "All Orders", href: "/admin/orders" },
      { title: "Pending", href: "/admin/orders?status=pending" },
      { title: "Processing", href: "/admin/orders?status=processing" },
      { title: "Completed", href: "/admin/orders?status=completed" },
    ],
  },
  {
    title: "Customers",
    icon: Users,
    href: "/admin/customers",
  },
  // {
  //   title: "Analytics",
  //   icon: BarChart3,
  //   href: "/admin/analytics",
  // },
];

const settingsNavItems = [
  // {
  //   title: "Discounts",
  //   icon: Tag,
  //   href: "/admin/settings/discounts",
  // },
  {
    title: "Settings",
    icon: Settings,
    href: "/admin/settings",
  },
];

export function AppSidebar() {
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // Build current URL with search params for accurate comparison
  const currentUrl = searchParams.toString()
    ? `${pathname}?${searchParams.toString()}`
    : pathname;

  // Helper to check if a menu item is active
  const isActiveLink = (href: string) => {
    // For links with query params, compare full URL
    if (href.includes("?")) {
      return currentUrl === href;
    }
    // For links without query params, only match if current URL also has no params
    // This prevents "/admin/orders" from matching when we're at "/admin/orders?status=pending"
    return pathname === href && !searchParams.toString();
  };

  return (
    <Sidebar variant="inset" collapsible="icon" >
      <SidebarHeader className="border-b flex flex-col gap-2">
        <Link href="/" className="flex items-center gap-2 px-2 py-2 group-data-[collapsible=icon]:p-2!">
          <div className="flex h-6 w-6 items-center justify-center rounded-lg">
            <Hexagon className="h-6 w-6 text-primary" strokeWidth={3} />
          </div>
          <div className="flex flex-col group-data-[collapsible=icon]:hidden">
            <span className="text-sm font-semibold">Hexa Shop</span>
            <span className="text-xs text-muted-foreground">Admin Panel</span>
          </div>
        </Link>

      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Main Menu</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {mainNavItems.map((item) =>
                item.items ? (
                  <Collapsible
                    key={item.title}
                    asChild
                    className="group/collapsible"
                  >
                    <SidebarMenuItem>
                      <CollapsibleTrigger asChild>
                        <SidebarMenuButton>
                          {item.icon && <item.icon />}
                          <span>{item.title}</span>
                          <ChevronRight className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-90" />
                        </SidebarMenuButton>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <SidebarMenuSub>
                          {item.items.map((subItem) => (
                            <SidebarMenuSubItem key={subItem.title}>
                              <SidebarMenuSubButton
                                asChild
                                isActive={isActiveLink(subItem.href)}
                              >
                                <Link href={subItem.href}>
                                  {subItem.title}
                                </Link>
                              </SidebarMenuSubButton>
                            </SidebarMenuSubItem>
                          ))}
                        </SidebarMenuSub>
                      </CollapsibleContent>
                    </SidebarMenuItem>
                  </Collapsible>
                ) : (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActiveLink(item.href)}
                    >
                      <Link href={item.href}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                )
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel>Settings</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {settingsNavItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton
                    asChild
                    isActive={isActiveLink(item.href)}
                  >
                    <Link href={item.href}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <FooterUser />
      </SidebarFooter>
    </Sidebar>
  );
}
