import { CustomersPageClient } from "./_components/customers-page-client";

export default function CustomersPage() {
   return <CustomersPageClient />;
}
