import { DiscountsPageClient } from "./_components/discounts-page-client";

export default function DiscountsPage() {
   return <DiscountsPageClient />;
}
