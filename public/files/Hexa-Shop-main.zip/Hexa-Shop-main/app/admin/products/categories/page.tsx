import { CategoriesPageClient } from "./_components/categories-page-client";

export default function CategoriesPage() {
  return <CategoriesPageClient />;
}
