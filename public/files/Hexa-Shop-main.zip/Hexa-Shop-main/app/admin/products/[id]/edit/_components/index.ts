export { ProductEditPageClient } from "./product-edit-page-client";
