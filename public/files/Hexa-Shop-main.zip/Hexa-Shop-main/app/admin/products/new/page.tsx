import { ProductAddPageClient } from "./_components/product-add-page-client";

export default function ProductAddPage() {
  return <ProductAddPageClient />;
}