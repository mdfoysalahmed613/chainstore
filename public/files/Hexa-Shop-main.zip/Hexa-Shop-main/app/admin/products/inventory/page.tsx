import { InventoryPageClient } from "./_components/inventory-page-client";

export default function InventoryPage() {
  return <InventoryPageClient />;
}
