import { ProductsPageClient } from "./_components/products-page-client";

export default function ProductsPage() {
   return <ProductsPageClient />;
}
