import { OrderDetailContent } from "./_components/order-detail-content";

export default function OrderDetailPage() {
   return <OrderDetailContent />;
}
