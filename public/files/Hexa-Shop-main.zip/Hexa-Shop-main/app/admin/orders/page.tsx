import { OrdersContent } from "./_components/orders-content";

export default function OrdersPage() {
   return <OrdersContent />;
}
