import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Inter } from "next/font/google";
import { Toaster } from "sonner";
import { SpeedInsights } from "@vercel/speed-insights/next";
import GoogleAnalytics from "@/components/common/google-analytics";
import Navbar from "@/components/common/nav";
import Footer from "@/components/common/footer";
import ProfileImage from '@/public/md-foysal-ahmed.jpg'

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#c75605",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_BASE_URL!),
  title: {
    default: "Md Foysal Ahmed | Websites That Bring You Customers",
    template: `%s | Md Foysal Ahmed`,
  },
  description: "I help local businesses and service providers attract more customers with fast, modern websites that convert visitors into paying clients.",

  authors: [{ name: "Md Foysal Ahmed", url: process.env.NEXT_PUBLIC_BASE_URL! }],
  creator: "Md Foysal Ahmed",


  openGraph: {
    title: "Md Foysal Ahmed | Websites That Bring You Customers",
    description:
      "I help local businesses and service providers attract more customers with fast, modern websites that convert visitors into paying clients.",
    url: process.env.NEXT_PUBLIC_BASE_URL!,
    siteName: "Md Foysal Ahmed",
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Md Foysal Ahmed | Websites That Bring You Customers",
    description:
      "I help local businesses and service providers attract more customers with fast, modern websites that convert visitors into paying clients.",
  },
  keywords: [
    "Md Foysal Ahmed",
    "Business Website Developer",
    "Website for Small Business",
    "Lead Generation Website",
    "Bangladesh Web Developer",
    "Dhaka Web Developer",
    "Modern Website Design",
    "Fast Website Developer",
    "Local Business Website",
    "Service Business Website",
    "Website That Gets Customers",
    "Next.js Developer Bangladesh",
    "Professional Business Website",
  ],
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  category: "Portfolio",
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/icons/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Md Foysal Ahmed",
  },
};

export default function RootLayout({ children, }: { children: React.ReactNode }) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Person",
    "name": "Md Foysal Ahmed",
    "url": "https://foysal.me",
    "image": `${process.env.NEXT_PUBLIC_BASE_URL}${ProfileImage.src}`,
    "sameAs": [
      "https://github.com/mdfoysalahmed613",
      "https://www.linkedin.com/in/mdfoysalahmed613",
      "https://www.facebook.com/foysal613"
    ],
    "jobTitle": "Web Developer for Businesses",
    "worksFor": {
      "@type": "Organization",
      "name": "Freelance"
    },
    "description": "I help local businesses and service providers attract more customers with fast, modern websites that convert visitors into paying clients.",
    "email": "contact@foysal.me",
    "telephone": "+8801581633810",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Dhaka",
      "addressCountry": "Bangladesh"
    }
  }

  return (
    <html lang="en" suppressHydrationWarning >
      <head>
        <link rel="preconnect" href="https://www.googletagmanager.com" />
        <link rel="preconnect" href="https://www.google-analytics.com" />
        <link rel="dns-prefetch" href="https://www.googletagmanager.com" />
        <link rel="dns-prefetch" href="https://www.google-analytics.com" />
      </head>
      <body className={`${inter.className} antialiased flex flex-col max-w-[1400px] mx-auto w-full px-4 sm:px-6 lg:px-8`}>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <GoogleAnalytics />
        <SpeedInsights />
        <Navbar />
        {children}
        <Footer />
        <Toaster position="top-center" richColors />
      </body>
    </html>
  );
}
