export const navItems = [
  {
    title: "Skills",
    href: "/#skills",
  },
  {
    title: "Services",
    href: "/#services",
  },
  {
    title: "Projects",
    href: "/#projects",
  },
  {
    title: "Blog",
    href: "/blog",
  },
  {
    title: "Contact",
    href: "/#contact",
  },
];
